{{/* Cette fonction permet de récupérer l'image du déploiement */}}
{{- define "rasa.image" -}}
{{ .Values.rasa.image.repository }}:{{ .Values.rasa.image.tag }}
{{- end -}}

{{/*
Nom complet de la release (ex: guic-dev-portail)
*/}}
{{- define "lemonldap-ng.fullname" -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Nom court de l'application
*/}}
{{- define "lemonldap-ng.name" -}}
{{- .Chart.Name -}}
{{- end -}}

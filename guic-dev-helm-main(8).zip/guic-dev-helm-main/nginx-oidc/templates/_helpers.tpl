{{- define "nginx-keycloak-auth.fullname" -}}
{{ printf "%s-%s" .Release.Name "nginx-oidc" }}
{{- end }}

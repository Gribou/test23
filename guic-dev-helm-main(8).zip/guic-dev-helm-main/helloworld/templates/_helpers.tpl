{{- define "browser-info-chart.name" -}}
{{ .Chart.Name }}
{{- end }}

{{- define "browser-info-chart.fullname" -}}
{{ include "browser-info-chart.name" . }}-{{ .Release.Name }}
{{- end }}

{{- /* templates/_helpers.tpl */ -}}

{{- define "lemonldap.name" -}}
{{- default "lemonldap" (default .Chart.Name .Values.nameOverride) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "lemonldap.fullname" -}}
{{- $name := include "lemonldap.name" . -}}
{{- $release := default "release" .Release.Name -}}
{{- printf "%s-%s" $release $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "lemonldap.labels" -}}
app.kubernetes.io/name: {{ include "lemonldap.name" . }}
app.kubernetes.io/instance: {{ default "release" .Release.Name }}
app.kubernetes.io/version: {{ default .Chart.AppVersion "1.0.0" }}
app.kubernetes.io/managed-by: Helm
{{- end -}}
